"use client"

export default function QuesterProfileSignupPage() {
  return <h1>I am the QuesterProfileSignupPage!</h1>
}