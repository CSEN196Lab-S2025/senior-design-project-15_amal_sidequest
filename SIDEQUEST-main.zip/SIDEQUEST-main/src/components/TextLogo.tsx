"use client"

export default function TextLogo() {
  return <h1 className="text-2xl font-gray-800 font-bold">
    SIDEQUE<span className="text-theme-green">$</span>T
  </h1>
}